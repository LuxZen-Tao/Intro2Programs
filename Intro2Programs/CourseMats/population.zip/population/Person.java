
/**
 * Class Person 
 * 
 * @author ITP2006
 * @version 1.0
 */
public class Person
{
    // instance variables 
    private String name;
    private int age;

    /**
     * Constructor for objects of class Person. Pass in
     * a String for the name, an integer for the age, and
     * a String ("male" or "female") for the gender.
     */
    public Person(String myName, int myAge)
    {
        name = myName;
        age = myAge;
    }
    
    public String getName()
    {
        return name;
    }
    
    public int getAge()
    {
        return age;
    }
    
    
}
