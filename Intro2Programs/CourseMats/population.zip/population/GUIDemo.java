
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GUIDemo {
   JFrame frame = null;
   Container container = null;
   JButton button = null;
   ActionListener actionListener = null;
   MouseListener mouseListener = null; 
   Canvas canvas = null;
   Image image = null;
   int xClick = -1, yClick = -1;

   public void v1() { 
      frame = new JFrame("GUI demo");
      frame.setLocation(280, 150);
      frame.setVisible(true);
   }

   public void v2() { /* add a button */
      v1(); 
      container = frame.getContentPane();
      button = new JButton("Yes");
      container.add(button); 
      frame.setSize(300, 200); 
   }

   public void v3() { /* make the button do something */
      v2();
      actionListener = new ActionListener() { 
         public void actionPerformed(ActionEvent e) {
            button.setText(button.getText() == "Yes" ? "No " : "Yes");
         }
      };
      button.addActionListener(actionListener);
   }

   public void v4() { /* add a canvas to draw on */
      v3();
      canvas = new Canvas() {
         public void paint(Graphics g) {
            g.drawString("hello", 10, 10);
            g.drawLine(10,15,19,40);
            if (button.getText() == "Yes") g.fillOval(50,20,20,30);
         }                                       
      };
      canvas.setSize(200, 250);
      canvas.setBackground(Color.orange);
      container.setLayout(new BoxLayout(container, BoxLayout.X_AXIS));
      container.removeAll();
      container.add(canvas);
      container.add(button);
      button.removeActionListener(actionListener);
      actionListener = new ActionListener() { 
         public void actionPerformed(ActionEvent e) {
            button.setText(button.getText() == "Yes" ? "No " : "Yes");
            canvas.repaint(); 
         }
      };
      button.addActionListener(actionListener);
   }

   public void v5() { /* add an image */
      v4();
      image = frame.getToolkit().getImage("thornton-pic.gif");
      mouseListener = new MouseListener() {
         public void mouseClicked(MouseEvent e) {
            xClick = e.getX(); 
            yClick = e.getY();
            canvas.repaint(); 
         }
         public void mouseExited(MouseEvent e) { }
         public void mouseEntered(MouseEvent e) { }
         public void mousePressed(MouseEvent e) { }
         public void mouseReleased(MouseEvent e) { }
      };
      container.remove(canvas);
      canvas = new Canvas() {
         public void paint(Graphics g) {
            g.setColor(Color.black);
            g.drawString("hello", 10, 10);
            g.drawLine(10,15,19,40);
            if (button.getText() == "Yes") g.fillOval(50,20,20,30);
            g.drawImage(image, 80, 25, this);
            if (xClick != -1) {
               g.setColor(Color.red);
               g.fillOval(xClick, yClick, 10, 10); }
         }                                        
      };
      canvas.addMouseListener(mouseListener);
      canvas.setBackground(new Color(0.8f, 0.8f, 1.0f));
      canvas.setSize(200, 250);
      container.removeAll();
      container.add(canvas);
      container.add(button);
   }

   public static void main(String args[]) {
      GUIDemo d = new GUIDemo();
      String s = (args.length > 0 ? args[0].intern() : "1");
      if (s == "1") d.v1();
      if (s == "2") d.v2();
      if (s == "3") d.v3();
      if (s == "4") d.v4();
      if (s == "5") d.v5();
   }

}
