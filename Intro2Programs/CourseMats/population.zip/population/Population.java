import java.util.ArrayList;


/**
 * Class Population: represents a collection of people
 * 
 * @author Bill Keller
 * @version 26/10/07
 */
public class Population
{
    // field people is an array of Person objects
    private Person[] population;
    private int personCount;

    /**
     * Initialise population. Sets people field to an array object.
     */
    public Population( int popSize )
    {
        population = new Person[ popSize ]; 
        personCount = 0;
    }

    /**
     * addPerson adds a Person object to the population
     */
    public void addPerson( Person p )
    {
        if ( personCount < population.length ) {
            population[ personCount ] = p;
            personCount++;
        } else {
            System.out.println("Population capacity exceded!");
        }
    }
    
    /**
     * totalAge calculates the sum of the ages of all Person objects in the population
     */
    public int totalAge() 
    {
        int totalAge = 0;
        for ( int i = 0; i<personCount; i++ ) {
            totalAge = totalAge + population[i].getAge();
        }
        return totalAge;
    }
    
    /**
     * averageAge calculates the average age of people in the population.
     */
    public double averageAge()
    {
        if (personCount == 0) {
            return 0.0;
        }
        else {
            int total = totalAge();
            return ((double)total)/personCount;
        }
    }    
        
    
}
